Plastic Surgery
Sleepy068

WARNING: !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
This mod is dependant on CRP, you must have it installed for it to work:
You install it in the exact same manner as below.
https://github.com/sleepy068/CommunityResourcePack/releases


Installing:
1. Extract the zip file (to where ever if need be)
2. Delete any previous versions of the mod at the steam path below, do NOT override the files.
3. Copy the file 'Mod_PlasticSurgery' to your Project Hospital installation addon's folder (see below).

Steam Path: C:\Program Files (x86)\Steam\steamapps\common\Project Hospital\ProjectHospital_Data\StreamingAssets\Addons\*put mod here*

4. Done, launch the game and enjoy.

Troubleshooting:
- Mod didn't load?
Make sure the mod's path file is as follows:
C:\Program Files (x86)\Steam\steamapps\common\Project Hospital\ProjectHospital_Data\StreamingAssets\Addons\Mod_PlasticSurgery
In the mod file should be Database, heaps of PNGs, steamworkshop ID & Preview.png
Check the picture named 'where the mod should be' if you need further assistance.

- Mod issues?
Make sure you have the dependant mod Community Resource Pack installed as noted above.

- Bugs or issues?
Please report any issues here: https://github.com/sleepy068/ProjectHospital_PlasticSurgery/issues
